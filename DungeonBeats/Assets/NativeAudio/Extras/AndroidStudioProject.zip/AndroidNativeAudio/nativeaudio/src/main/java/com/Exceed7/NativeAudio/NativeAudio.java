package com.Exceed7.NativeAudio;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;

import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.util.Pair;

import com.unity3d.player.UnityPlayer;

// Native Audio
// 5argon - Exceed7 Experiments
// Problems/suggestions : 5argon@exceed7.com

public class NativeAudio {

    //Log is visible on adb logcat
    private final static boolean enableLogging = false;

    private static void Log(String message) {
        if (enableLogging) {
            Log.i("Android Native Audio", message);
        }
    }

    private static ArrayList<AudioTrackExtension> audioTracks;
    private static ArrayList<byte[]> audioByteArrays;

    //Our conventions are here.
    private final static int sampleRate = 44100;
    private final static int bitPerSample = 16;
    private final static int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
    private final static int bytePerSample = 2; //16bit = 2 byte
    private final static int channels = 2; //Stereo

    //To hold additional data tied to AudioTrack
    private static class AudioTrackExtension {
        private AudioTrack audioTrack;
        private int bufferSizeByte;
        private int loadedAudioByteArrayIndex = -1;

        private AudioTrack getAudioTrack() {
            return audioTrack;
        }

        private void Rebuild(int requiredBytes) {
            this.audioTrack.release();

            AudioTrackExtension newAte = BuildAudioTrack(requiredBytes);
            this.audioTrack = newAte.audioTrack;
            this.bufferSizeByte = newAte.bufferSizeByte;
            this.loadedAudioByteArrayIndex = -1;
            Log("Rebuild into size: " + this.bufferSizeByte);
        }

        //Check if AudioTrack is ready to play a specific sound or not. Needs to be loaded first.
        private boolean isReadyToPlay(int byteArrayIndex) {
            Log("Checking isReadyToPlay of AudioTrack with loadedIndex: " + loadedAudioByteArrayIndex + " byteArrayIndex: " + byteArrayIndex);
            if (loadedAudioByteArrayIndex == byteArrayIndex && !isPlaying()) {
                return true;
            }
            return false;
        }

        private boolean isPlaying() {
            if (audioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                //We consider play head at the end as not playing too.
                int playbackHeadFrame = audioTrack.getPlaybackHeadPosition();

                //audioTrack.getBufferCapacityInFrames() is not compatible with older API so we have to calculate it..
                int frameSizeInByte = NativeAudio.channels * NativeAudio.bytePerSample; //2 channel * 16bit pcm
                int bufferSizeFrame = this.bufferSizeByte / frameSizeInByte;

                Log("Is playing " + bufferSizeFrame + " vs " + playbackHeadFrame);
                if (playbackHeadFrame >= bufferSizeFrame) {
                    return false; //state is playing, but we consider it not playing.
                } else {
                    return true;
                }
            } else {
                return false;
            }
        }

        private AudioTrackExtension(AudioTrack audioTrack, int bufferSize) {
            //Lower API level could not determine bufferSizeByte reliably, so we just have to remember it.
            this.audioTrack = audioTrack;
            this.bufferSizeByte = bufferSize;
        }

        //Also stop it if it is playing.
        private void Load(int byteArrayIndex) {
            byte[] audio = audioByteArrays.get(byteArrayIndex);

            if (audioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                audioTrack.stop();
            }

            //Required to reset the play head. Or else the new audio will have the old play head...
            audioTrack.reloadStaticData();

            //Check before writing if it fits?
            int requiredBytes = audio.length;
            Log("Checking the size of audio: " + requiredBytes + " vs. size allocated: " + this.bufferSizeByte);
            if (requiredBytes > this.bufferSizeByte) {
                Log("Require reinstantiating of AudioTrack to size: " + requiredBytes);
                this.Rebuild(requiredBytes);
            }

            //We need a zero padding if the size of AudioTrack is larger.
            byte[] zeroPaddedByte = new byte[this.bufferSizeByte];
            System.arraycopy(audio, 0, zeroPaddedByte, 0, audio.length);

            this.audioTrack.write(zeroPaddedByte, 46, zeroPaddedByte.length - 46); //46 is to avoid .wav header fields (Some sources say it is 44...)
            loadedAudioByteArrayIndex = byteArrayIndex;
        }
    }

    private static int BufferSizeFromSeconds(float seconds) {
        final int bitRate = (NativeAudio.bitPerSample * NativeAudio.sampleRate * NativeAudio.channels);
        final int bufferSize = (int) ((bitRate * seconds) / 8.0f); //to byte
        return bufferSize;
    }

    // There is a hard limit of AudioTrack per app. In my test it is 24.
    // On 25th create it will output : AudioFlinger could not create track. status: -12
    private static AudioTrackExtension BuildAudioTrack(int maxBufferSize) {

        // I want to support down to Jelly Bean (API Lv.16) like what Unity defaults to.. and this code turns into a nightmare..
        // Higher API might be able to make an AudioTrack with better latency. Be wary of this.

        AudioTrack newAudioTrack;

        //I decided on MODE_STATIC since it potentially has the lowest latency but we have some trade offs :
        //1. The size needs to be given while creating it. How large should it be?
        //2. The common strategy is to create a new AudioTrack every time you play a sound then we could make the size fit an audio perfectly.
        //3. To minimize latency, I want to create all AudioTrack at once at Initialize and not when playing. So we can't do that.
        //4. An approach is we will have a fixed size that is large enough for all possible audio in your game. We instantiate all
        //AudioTrack to this size. We lose more memory than we have to in exchange for not having to worry about overflowing bufferSizeByte
        //5. There is a backup measure when an incoming sound is larger. We will reinstantiate only that AudioTrack to fit that sound and left it
        //at that size. Other AudioTrack remains at starting fixed size.

        final int modeStatic = AudioTrack.MODE_STATIC;

        final int bufferSize = maxBufferSize;

        if (Build.VERSION.SDK_INT >= 21) {

            AudioFormat audioFormat = new AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(audioEncoding)
                    .build();

            AudioAttributes audioAttributes;
            AudioAttributes.Builder audioAttributesBuilder = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION);

            if (Build.VERSION.SDK_INT >= 24 && Build.VERSION.SDK_INT <= 25) // <-- Nougat 7.0 / 7.1 has the flag in AudioAttribute
            {
                audioAttributesBuilder.setFlags(AudioAttributes.FLAG_LOW_LATENCY);
            }

            audioAttributes = audioAttributesBuilder.build();

            if (Build.VERSION.SDK_INT >= 23) { // <-- Must be over Marshmallow to use the builder
                AudioTrack.Builder audioTrackBuilder = new AudioTrack.Builder()
                        .setAudioAttributes(audioAttributes)
                        .setBufferSizeInBytes(bufferSize)
                        .setTransferMode(modeStatic)
                        .setAudioFormat(audioFormat);
                if (Build.VERSION.SDK_INT >= 26) // <-- Oreo moves the flag to AudioTrack
                {
                    audioTrackBuilder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
                }
                newAudioTrack = audioTrackBuilder.build();
            } else if (Build.VERSION.SDK_INT >= 21) // <-- Must be over Lollipop for this modern constructor
            {
                newAudioTrack = new AudioTrack(audioAttributes, audioFormat, bufferSize, modeStatic, AudioManager.AUDIO_SESSION_ID_GENERATE);
            } else // Old constructor with missing features
            {
                newAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_STEREO,
                        audioEncoding, bufferSize, modeStatic);
            }
        } else // Old constructor with missing features
        {
            newAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_STEREO,
                    audioEncoding, bufferSize, modeStatic);
        }

        return new AudioTrackExtension(newAudioTrack, bufferSize);
    }

    private static boolean initialized = false;

    public static int Initialize(int numberOfAudioTracks, float maxAudioLength) {
        Log("Initializing Native Audio with " + numberOfAudioTracks + " AudioTracks.");

        if (audioTracks == null) {
            audioTracks = new ArrayList<>();
        }
        if (audioByteArrays == null) {
            audioByteArrays = new ArrayList<>();
        }

        //We have to try allocating all needed ATs, is it over the hard limit?
        for (int i = 0; i < numberOfAudioTracks; i++) {
            try {
                int calculateBufferSize = BufferSizeFromSeconds(maxAudioLength);
                Log("From maximum audio length of " + maxAudioLength + " the starting buffer size is :" + calculateBufferSize);
                AudioTrackExtension ate = BuildAudioTrack(calculateBufferSize);
                audioTracks.add(ate);
            } catch (UnsupportedOperationException e) {
                //There is a quota of alloc-able AudioTrack per device at the same time.
                //With only Unity I found that it is 24, but yours might varies.
                //The only way to check is catching the exception like this.
                Log(e.getMessage());
                if (audioTracks.size() == 0) {
                    return -1;
                }
                initialized = true;
                return audioTracks.size(); //Total alloc-able is returned as an error.
            }
        }
        initialized = true;
        return 0; //0 = no error
    }

    public static void PrepareAudio(int byteArrayIndex) {
        Log("Manually preparing to play byteArrayIndex: " + byteArrayIndex);
        //Discards the returned AudioTrack. When we Play next we would get that AudioTrack anyways.
        PrepareAudioTrackToPlay(byteArrayIndex);
    }

    //Make byte[] for audio and store them. Reference them back by the ArrayList index.
    //We should never remove items from audioByteArrays, or this indexing scheme will be screwed up.
    //When we unload byte[] we just left them in ArrayList like that.
    public static int LoadAudio(String audioPath) {
        Log("Loading " + audioPath);

        if (!initialized) {
            //LoadAudio cannot call Initialize automatically because we need to know the desired AudioTrack amount.
            //This number setting is on the managed side, so we leave the Load -> Initialize logic to that.
            //(That is, we should never arrive at this point if the code at managed side is correct.)
            Log.e("Android Native Audio", "Cannot load an audio without initializing Native Audio first.");
            return -1;
        }

        Context context = UnityPlayer.currentActivity;

        //Normally, Application.streamingAssetsPath looks like this :
        //jar:file:///data/app/com.Exceed7.NativeAudio-1/base.apk!/assets

        //In OBB, Application.streamingAssetsPath looks like this :
        //jar:file:///storage/emulated/0/Android/obb/com.Exceed7.NativeAudio/main.1.com.Exceed7.NativeAudio.obb!/assets

        //context.getAssets() cannot find things there. It will look in the base APK and found nothing...
        //This is where we will use : https://github.com/google/play-apk-expansion

        AssetManager assetManager = context.getAssets();

        ZipResourceFile obbFiles;

        int versionCode = -1;
        try {
            versionCode = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return -1;
        }

        try {
            //Even without OBB present, this will "new" the ZipResourceFile anyways.
            //With OBB, it collects all of the expansion and patch them into one.
            obbFiles = APKExpansionSupport.getAPKExpansionZipFile(context, versionCode, 0);
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }

        if(enableLogging) {
            ZipResourceFile.ZipEntryRO[] allEntries = obbFiles.getAllEntries();
            for (ZipResourceFile.ZipEntryRO zero : allEntries) {
                Log("Expansion file content : " + zero.mFileName + " " + zero.mZipFileName);
            }
        }

        try {
            AssetFileDescriptor descriptor = assetManager.openFd(audioPath);
            byte[] music = new byte[(int) descriptor.getLength()];

            InputStream is = assetManager.open(audioPath);
            is.read(music);
            is.close();

            audioByteArrays.add(music);
            Log("Loaded audio " + audioPath + " from the main APK.");

        } catch (IOException e) {
            //Now is the chance to try looking at OBB...
            try {
                AssetFileDescriptor descriptorFromObb = obbFiles.getAssetFileDescriptor("assets/" + audioPath);
                byte[] music = new byte[(int) descriptorFromObb.getLength()];
                InputStream is = obbFiles.getInputStream("assets/" + audioPath);
                is.read(music);
                is.close();
                audioByteArrays.add(music);
                Log("Loaded audio " + audioPath + " from an OBB expansion file.");
            } catch (IOException | NullPointerException e2) {
                //Null pointer is when we .getLength from an invalid descriptorFromObb.
                Log("Error reading audio file " + audioPath);
                e2.printStackTrace();
                return -1;
            }
        }

        int byteArrayIndexOfLoaded = audioByteArrays.size() - 1;

        Log("Loaded to byteArrayIndex: " + byteArrayIndexOfLoaded);
        return byteArrayIndexOfLoaded;
    }

    //You should not call this twice with the same index, which Unity side will prevent.
    //Index is never reused, new audio tracks will goes forward.
    public static void UnloadAudio(int byteArrayIndex) {
        Log("Unloading byteArrayIndex: " + byteArrayIndex);
        try {
            //How you release byte[] memory in Java is to remove all the references and wait for garbage collector.
            audioByteArrays.set(byteArrayIndex, null);

            //The only other places is maybe it is in one of the AudioTrack.
            //But I believe with `write` we have copied the memory, not reference.
            //We will just left them like that. A new load will overwrite it.
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Pair<AudioTrack,Integer> PrepareAudioTrackToPlay(int byteArrayIndex) {
        Log("Preparing byteArrayIndex: " + byteArrayIndex);
        AudioTrackExtension candidate = null;
        int candidateIndex = -1;
        //First we will search if any AT is already loaded with this audio and is not playing.

        for (int i = 0; i < audioTracks.size() ; i++) {
            AudioTrackExtension ate = audioTracks.get(i);
            if (ate.isReadyToPlay(byteArrayIndex)) {
                Log("Found already loaded AudioTrack.");
                return Pair.create(ate.getAudioTrack(),i);
            } else if (!ate.isPlaying()) {
                if (candidate == null) {
                    //This is a candidate that we can put our audio in, in case we found nothing.
                    candidate = ate;
                    candidateIndex = i;
                }
            }
        }

        //We can't find any AT with desired audio but we found any non-playing ones. We will load into that.
        if (candidate != null) {
            Log("Loading audio into a non-playing AudioTrack.");
            candidate.Load(byteArrayIndex);
            return Pair.create(candidate.getAudioTrack(),candidateIndex);
        } else {
            //If everything is playing we have to forcibly stop some AudioTrack.
            //My approach is just to stop the first one. (Maybe we better stop the oldest one, but I did not track that information)
            Log("Forced stop a playing AudioTrack and load a new audio into it.");
            audioTracks.get(0).Load(byteArrayIndex);
            return Pair.create(audioTracks.get(0).getAudioTrack(), 0);
        }
    }

    public static int PlayAudio(int byteArrayIndex, float volume, float pan) {
        Log("Playing byteArrayIndex: " + byteArrayIndex + " volume: " + volume + " pan: " + pan);
        Pair<AudioTrack,Integer> pair = PrepareAudioTrackToPlay(byteArrayIndex);
        AudioTrack at = pair.first;
        try {

            float leftVolume = volume;
            float rightVolume = volume;

            //Pan of -1.0 means only left side remains, 1.0 only right.

            if (pan > 0) {
                leftVolume *= 1 - pan;
            }
            if (pan < 0) {
                rightVolume *= 1 - (-pan);
            }

            int playState = at.getPlayState();
            if (playState == AudioTrack.PLAYSTATE_PLAYING) {
                at.stop();
                at.reloadStaticData();
                at.setStereoVolume(leftVolume, rightVolume);
                at.play();
            }
            if (playState == AudioTrack.PLAYSTATE_STOPPED) {
                at.reloadStaticData();
                at.setStereoVolume(leftVolume, rightVolume);
                at.play();
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
            return -1;
        }
        return pair.second;
    }

    public static void StopAudio(int audioTrackIndex)
    {
        Log("Stop audioTrackIndex: " + audioTrackIndex);
        AudioTrack at = audioTracks.get(audioTrackIndex).getAudioTrack();
        int playState = at.getPlayState();
        if (playState == AudioTrack.PLAYSTATE_PLAYING) {
            at.stop();
            at.reloadStaticData();
        }
        if (playState == AudioTrack.PLAYSTATE_STOPPED) {
            at.reloadStaticData();
        }
    }

    // Bonus
    public static String AskFeatures() {
        String reportString = "";
        PackageManager packageManager = UnityPlayer.currentActivity.getPackageManager();
        boolean hasLowLatencyFeature = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY);

        boolean hasProFeature = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_PRO);
        Log.d("LOW LATENCY FEATURE : ", String.valueOf(hasLowLatencyFeature));
        Log.d("PRO AUDIO FEATURE : ", String.valueOf(hasProFeature));
        String nativeSampleRate = "-";
        String optimalBufferSize = "-";
        if (Build.VERSION.SDK_INT >= 17) {
            AudioManager myAudioMgr = (AudioManager) UnityPlayer.currentActivity.getSystemService(UnityPlayer.currentActivity.getApplicationContext().AUDIO_SERVICE);
            nativeSampleRate = myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE);
            Log.d("NATIVE SAMPLING RATE : ", nativeSampleRate);

            optimalBufferSize = myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER);
            Log.d("OPTIMAL BUFFER SIZE : ", optimalBufferSize);
        }
        return "LOW LATENCY : " + hasLowLatencyFeature + " PRO AUDIO : " + hasProFeature + " NATIVE SAMPLING RATE : "
                + (nativeSampleRate) + " OPTIMAL BUFFER SIZE : " + optimalBufferSize;
    }
}
